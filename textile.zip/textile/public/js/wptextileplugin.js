jQuery(document).ready(function($) {
    var data = TEXTILE_AJAX_OBJ ? TEXTILE_AJAX_OBJ : {};
    var textile = new WPTextilePlugin(data);

});

var WPTextilePlugin = (
    function($) {
        var constructor = function(data) {
           
        }


        return constructor;
    }
)(jQuery);